<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\FeePlanType */

?>
<div class="fee-plan-type-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
