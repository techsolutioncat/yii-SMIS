<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\FineType */

?>
<div class="fine-type-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
