<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\RefClass */
?>
<div class="ref-class-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
