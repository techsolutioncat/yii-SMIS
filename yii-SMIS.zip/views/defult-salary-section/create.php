<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\DefultSalarySection */

?>
<div class="defult-salary-section-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
