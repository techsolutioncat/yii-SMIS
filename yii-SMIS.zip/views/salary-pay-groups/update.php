<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\SalaryPayGroups */
?>
<div class="salary-pay-groups-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
