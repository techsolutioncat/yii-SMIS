<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\HostelRoom */

?>
<div class="hostel-room-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
