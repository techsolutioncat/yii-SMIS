<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\FeeGroup */
?>
<div class="fee-group-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
