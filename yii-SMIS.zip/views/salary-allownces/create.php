<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\SalaryAllownces */

?>
<div class="salary-allownces-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
