<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\SalaryAllownces */
?>
<div class="salary-allownces-update">

    <?= $this->render('_form', [
        'model' => $model,
        
    ]) ?>

</div>
