<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\FeeHeadWise */
?>
<div class="fee-head-wise-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
