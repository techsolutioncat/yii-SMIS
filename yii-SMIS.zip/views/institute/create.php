<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\RefInstituteType */

?>
<div class="ref-institute-type-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
