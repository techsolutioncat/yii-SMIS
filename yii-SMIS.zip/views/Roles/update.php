<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\UserRoles */
?>
<div class="user-roles-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
