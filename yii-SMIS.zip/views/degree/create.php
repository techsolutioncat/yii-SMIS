<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\RefDegreeType */

?>
<div class="ref-degree-type-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
