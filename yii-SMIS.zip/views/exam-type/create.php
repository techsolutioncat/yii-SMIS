<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ExamType */

?>
<div class="exam-type-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
