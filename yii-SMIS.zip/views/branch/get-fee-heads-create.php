
<select class="form-control fee_modes" name="FeeHeads[fk_fee_method_id]">
                <option value="">Select Fee Modes</option>
              </select>